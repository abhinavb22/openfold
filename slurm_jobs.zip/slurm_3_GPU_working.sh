#!/bin/bash
##NECESSARY JOB SPECIFICATIONS
#SBATCH --job-name=of_train  #Set the job name to Example_SNMC_GPU
#SBATCH --time=12:00:00              #Set the wall clock limit to 1hr 30min
#SBATCH --nodes=1                    #Request 1 nodes
#SBATCH --ntasks-per-node=1         #Request 32 tasks/cores per node
#SBATCH --cpus-per-task=8
#SBATCH --mem=512G                   #Request 248G (248GB) per node
#SBATCH --output=/scratch/user/u.as139299/outerror/out.%j #Redirect stdout/err to file
#SBATCH --error=/scratch/user/u.as139299/outerror/err.%j #Redirect stdout/err to file
#SBATCH --partition=gpu              #Specify partition to submit job to
#SBATCH --gres=gpu:a100:8           #Specify GPU(s) per node, 10 a100 GPU

##OPTIONAL JOB SPECIFICATIONS 
##SBATCH --account=146392998287            #Set billing account to 146392998287
##SBATCH --mail-type=FAIL             #Send email on all job events
##SBATCH --mail-user=abhinav22@tamu.edu   #Send all emails to email_address


module purge

module load GCC/11.2.0
module load CUDA/12.2
module load Anaconda3
source activate openfold_cuda12

export PYTORCH_CUDA_ALLOC_CONF=max_split_size_mb:128
export NCCL_DEBUG=INFO
export NCCL_IB_DISABLE=1
export NCCL_P2P_LEVEL=NVL

#master_addr=$(scontrol show hostnames "$SLURM_JOB_NODELIST" | head -n 1)
#export MASTER_ADDR=$master_addr
#export MASTER_PORT=51774
#export WORLD_SIZE=6  # Since you are using 2 GPUs
#export RANK=0 

DATA_DIR=/scratch/group/alphafold_classifier/openfold_files/openfold_training/oligomers
TEMPLATE_MMCIF_DIR=/scratch/user/u.as139299/database/pdb_mmcif
CHECKPOINT_PATH=../openfold/resources/params/params_model_1_multimer_v3.npz
CACHE_DIR=$DATA_DIR/cache_dir
OPENFOLD_CKPT_PATH=/scratch/10110/abhinav22/output_dir/openfold_training/z5jvbom5/checkpoints/17-612.ckpt
OUTPUT_PATH=/scratch/user/u.as139299/openfold_training
# Generate a unique port number based on the job ID
export MASTER_PORT=$(shuf -i 29400-65000 -n 1)

# Get the hostname of the first node
export MASTER_ADDR=$(scontrol show hostnames $SLURM_JOB_NODELIST | head -n 1)

export WANDB_DIR=$OUTPUT_PATH 
srun torchrun \
    --nnodes=1 \
    --nproc_per_node=8 \
    --rdzv_id=$SLURM_JOB_ID \
    --rdzv_backend=c10d \
    --rdzv_endpoint=$MASTER_ADDR:$MASTER_PORT \
    ../train_openfold.py $DATA_DIR/mmcif_dir/train $DATA_DIR/alignment_dir/train $TEMPLATE_MMCIF_DIR/mmcif_files $OUTPUT_PATH 2021-09-30 \
	--config_preset model_1_multimer_v3 \
	--template_release_dates_cache_path $CACHE_DIR/template_mmcif_cache.json \
    --seed 77843 \
    --obsolete_pdbs_file_path $TEMPLATE_MMCIF_DIR/obsolete.dat \
    --resume_from_jax_params $CHECKPOINT_PATH \
  	--resume_model_weights_only False \
  	--train_mmcif_data_cache_path $CACHE_DIR/train_mmcif_cache.json \
  	--val_mmcif_data_cache_path $CACHE_DIR/val_mmcif_cache.json \
  	--val_data_dir $DATA_DIR/mmcif_dir/val \
  	--val_alignment_dir $DATA_DIR/alignment_dir/val \
  	--num_nodes 1 \
    --gpus 8 \
  	--train_epoch_len 100 \
  	--val_epoch_len 100 \
  	--max_epochs 1000 \
  	--checkpoint_every_epoch  \
  	--precision bf16-mixed \
  	--num_sanity_val_steps 0 \
  	--log_performance False \
  	--log_every_n_steps 1 \
	--log_lr \
  	--wandb \
  	--wandb_project openfold_training \
  	--experiment_name deepspeed_faster_8GPUs \
  	--experiment_config_json ../custom_config.json \
  	--accumulate_grad_batches 4 \
	--deepspeed_config_path ../deepspeed_config.json 

